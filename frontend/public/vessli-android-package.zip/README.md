# Vessli Android APK Builder Package
Version: 1.2.0
Package: com.vessli.app

## Method 1: Google Bubblewrap (Fastest - 1 Command)
1. Install Bubblewrap:
   npm install -g @bubblewrap/cli

2. Build Signed APK / AAB:
   bubblewrap build

## Method 2: Android Studio / Capacitor
1. Add Android Platform:
   npx cap add android

2. Build in Android Studio:
   npx cap open android -> Build -> Build APK(s)
